
def main():
    while True:
        pass
    for i in range(0, 10):
        pass


if __name__ == "__main__":
    main()
