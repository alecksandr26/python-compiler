var = 1

if var == 0:
    var2 = 1
else:
    var2 = 1
    print(var2)

    
