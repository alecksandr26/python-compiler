# Error: ERROR_EXPECT_FUNC_NAME
# def :
#     print("Hello There")


# Error: ERROR_EXPECT_LPAREM
# def var):
#     print("Hello there")



# Error: ERROR_EXPECT_RPAREM
# def var(:
#         print("Hello there")



# Error: ERROR_EXPECT_COLON_FOR_CODE_BLOCK
# if num == 2
#     print("Hello there")


# Error: ERROR_EXPECT_END_OF_LINE
# num = 23 + 32 num2 = 2


# Error: ERROR_IDENT_NOT_MATCH
# if num == 2:
# num = 2

# Error: ERROR_EXPECT_INIT_OR_CALL
# num 2

# Error: ERROR_EXPECT_IN
# for e range(0, 10):
#     pass
