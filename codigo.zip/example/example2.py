if 1 == 1:
    if 2 == 2:
        print("2 == 2")
    elif True:
        print("hiihiihi")
    elif False:
        print("hello there")

        
    else:
        num = 2
        if num == 2:
            print("num is two")
        name = "hello"
        print("Hello there", name)
        var = True and True == True
    print("Pedrito")

var = 2
