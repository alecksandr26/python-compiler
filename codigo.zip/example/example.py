

num = 1
x = 3.25342
# Hola
string_var = "hola"
string_two = """hola soy string 2"""
# lst_nums = [1,2,3]
# lst_strings = ["objeto_1", "objeto_2"]
if num == 1:
    x = 12353 * 2

else:
    x = 3 / 350050

num2 = 235
num3 = 5325

print("Hello there")



